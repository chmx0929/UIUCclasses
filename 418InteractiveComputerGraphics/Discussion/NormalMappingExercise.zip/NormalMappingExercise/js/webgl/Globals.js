var gl = null;     // WebGL context
var prg = null;    // The program (shaders)
var c_width = 0;   // Variable to store the width of the canvas (updated when needed by codeview.js)
var c_height = 0;  // Variable to store the height of the canvas (updated when needed by codeview.js)

